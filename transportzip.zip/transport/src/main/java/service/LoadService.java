package com.liveasy.transport.service;

import com.liveasy.transport.entity.Load;
import com.liveasy.transport.repository.LoadRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.UUID;

@Service
public class LoadService {
    @Autowired
    private LoadRepository loadRepository;

    public Load addLoad(Load load) {
        return loadRepository.save(load);
    }

    public List<Load> getLoadsByShipperId(UUID shipperId) {
        return loadRepository.findByShipperId(shipperId);
    }

    public Load getLoadById(UUID id) {
        return loadRepository.findById(id).orElse(null);
    }

    public Load updateLoad(UUID id, Load loadDetails) {
        Load load = loadRepository.findById(id).orElse(null);
        if (load != null) {
            load.setLoadingPoint(loadDetails.getLoadingPoint());
            load.setUnloadingPoint(loadDetails.getUnloadingPoint());
            load.setProductType(loadDetails.getProductType());
            load.setTruckType(loadDetails.getTruckType());
            load.setNoOfTrucks(loadDetails.getNoOfTrucks());
            load.setWeight(loadDetails.getWeight());
            load.setComment(loadDetails.getComment());
            load.setDate(loadDetails.getDate());
            return loadRepository.save(load);
        }
        return null;
    }

    public void deleteLoad(UUID id) {
        loadRepository.deleteById(id);
    }
}